# WalletApp agent requirements

Use this file for project working requirements. Read [ROADMAP.md](ROADMAP.md) for version scope, business rules, and scope reminders before making implementation decisions. Keep changes within the version the user has asked to build. Do not pull later-version features into an earlier version without the user's direction.

## Product and platform

- Personal wallet/account transaction tracker for Android only.
- Proposed lightweight stack: Kotlin, native Android Views with XML layouts, and Room for the local database. Keep dependencies minimal. Enable R8 optimization for release builds.
- Data stays on the device. No bank connection, cloud sync, or app lock is planned.
- Currency for the initial product is INR.
- Screenshots in `Screenshots-mymoney/` are visual references for records, analysis, accounts, categories, and daily flow. Treat them as design examples, not product instructions.

## Implementation authorization

- Build only when the user asks to start a version; the roadmap alone does not authorize implementation.

## Working rules

- `repository/` is the Android application project root. Keep all app source, configuration, Gradle files, build caches, generated output, and APKs inside that directory. Run builds and tests from `repository/` and open that folder in Android Studio. Do not create the Android project in the main WalletApp directory.
- Keep project instructions, the roadmap, wireframes, and visual reference assets in the main WalletApp directory.
- Keep implementation as simple as the approved wireframes; beautification comes in later versions.
- Keep the app and code as minimal as possible. Prefer simple, direct solutions; avoid bloated or overcomplicated code, unnecessary dependencies, abstractions, and features.
- Implement only the requested version's features.
- Save wireframes in `wireframes/` in the main WalletApp directory. Use `wallet-v<app-version>-wireframe-r<revision>.html`, with at least two digits for revisions (for example, `wallet-v1-wireframe-r02.html`). Increment the revision for each saved iteration within an app version and preserve earlier revisions. Start a new app version at `r01`.
- Ask the user for approval before future `AGENTS.md` updates, describing the proposed changes before editing.
- When committing and pushing work, use `GITHUB_PAT` from `repository/.env` for GitHub authentication; never print or commit the token.
- Commit frequently at meaningful checkpoints whenever appropriate, keeping commits focused and messages clear.
- When the user says a version is done or asks to start a new version, back up the completed or outgoing version in the top-level `backups/` directory, outside `repository/`.
- After completing each app version, archive that version's Codex chat.

